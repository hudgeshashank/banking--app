package com.example.banking._app.repository;

import com.example.banking._app.entity.Account;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AccountRepository extends JpaRepository<Account, Long> {
    Account findByAccountHolderName(String accountHolderName);
}
