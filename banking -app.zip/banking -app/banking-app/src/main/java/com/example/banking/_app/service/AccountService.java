package com.example.banking._app.service;

import com.example.banking._app.dto.AccountDto;


public interface AccountService {
    AccountDto createAccount(AccountDto accountDto);

    AccountDto getAccountById(Long id);
}
