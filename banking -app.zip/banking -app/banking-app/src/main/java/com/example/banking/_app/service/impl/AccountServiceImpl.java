package com.example.banking._app.service.impl;

import com.example.banking._app.dto.AccountDto;
import com.example.banking._app.entity.Account;
import com.example.banking._app.mapper.AccountMapper;
import com.example.banking._app.repository.AccountRepository;
import com.example.banking._app.service.AccountService;
import org.springframework.stereotype.Service;

@Service
public class AccountServiceImpl implements AccountService {

    private AccountRepository accountRepository;

    public AccountServiceImpl(AccountRepository accountRepository) {
        this.accountRepository = accountRepository;
    }

    @Override
    public AccountDto createAccount(AccountDto accountDto) {
        Account account = AccountMapper.mapToAccount(accountDto);
        Account savedAccount = accountRepository.save(account);
        return AccountMapper.mapToAccountDto(savedAccount);

    }

    @Override
    public AccountDto getAccountById(Long id) {
       Account account = accountRepository
               .findById(id)
               .orElseThrow( () -> new RuntimeException("Account does not exists"));
        return AccountMapper.mapToAccountDto(account);
    }
}
