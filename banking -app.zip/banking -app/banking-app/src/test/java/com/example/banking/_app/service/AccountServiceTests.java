package com.example.banking._app.service;

import com.example.banking._app.dto.AccountDto;
import com.example.banking._app.entity.Account;
import com.example.banking._app.repository.AccountRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;

import java.util.Optional;

public class AccountServiceTests {
    @Autowired
    private AccountService accountService;
    @Mock
    private AccountRepository accountRepository;


    @Test
    public void testGetAccountById() {
        Account account = new Account();
        account.setId(1L);
        account.setAccountHolderName("John");
        account.setBalance(100.0);

        Mockito.when(accountRepository.findById(1L)).thenReturn(Optional.of(account));

        AccountDto found = accountService.getAccountById(1L);

        Assertions.assertEquals(1L, found.getId());
        Assertions.assertEquals("John",found.getAccountHolderName());
        Assertions.assertEquals(100.0, found.getBalance());
    }
}
